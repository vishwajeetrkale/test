﻿namespace MedicineAppModels
{
    public class MedicineModel
    {
        public string MedicineName { get; set; }
        public string Brand { get; set; }
        public string Price { get; set; }
        public string ExpiryDate { get; set; }
        public string Notes { get; set; }
    }
}
