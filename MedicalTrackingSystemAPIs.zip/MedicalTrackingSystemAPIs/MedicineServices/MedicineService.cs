﻿namespace MedicineServices
{
    using MedicineAppModels;
    using MedicinesRepository;
    using System.Collections.Generic;
    using System.Linq;

    public interface IMedicineService
    {
        List<MedicineModel> GetMedicines();
    }

    public class MedicineService : IMedicineService
    {
        private readonly IAzureSQLRepository _sqlRepository;

        public MedicineService(IAzureSQLRepository sqlRepository)
        {
            _sqlRepository = sqlRepository;
        }

        public List<MedicineModel> GetMedicines()
        {
            string _query = $"Select Name, Brand, Price, ExpiryDate, Notes from Medicines ";
            return _sqlRepository.Get<MedicineModel>(_query).ToList();
        }
    }
}
