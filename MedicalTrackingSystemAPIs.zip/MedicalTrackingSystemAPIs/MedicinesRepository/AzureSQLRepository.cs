﻿namespace MedicinesRepository
{
    using Dapper;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;

    public interface IAzureSQLRepository
    {
        IEnumerable<T> Get<T>(string query) where T : class;
    }

    public class AzureSQLRepository : IAzureSQLRepository
    {
        private readonly IDbConnection _connection;

        public AzureSQLRepository()
        {
            SqlConnectionStringBuilder sConnB = new SqlConnectionStringBuilder()
            {
                DataSource = @"W10MSDNA85Z2ZZ\SQLEXPRESS",
                InitialCatalog = "MedicineTrakcingSystemDb"
            };

            _connection = new SqlConnection(sConnB.ConnectionString);
        }

        public IEnumerable<T> Get<T>(string query) where T : class
        {
            if (_connection.State == ConnectionState.Closed)
            {
                _connection.Open();
            }

            IList<T> result = SqlMapper.Query<T>(_connection, query, CommandType.Text).ToList();
            _connection.Close();
            return result;
        }

    }
}
