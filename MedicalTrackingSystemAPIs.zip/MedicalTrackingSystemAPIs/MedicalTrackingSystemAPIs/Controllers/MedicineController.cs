﻿using MedicineServices;
using System.Collections.Generic;
using System.Web.Http;
using MedicineAppModels;

namespace MedicalTrackingSystemAPIs.Controllers
{
    public class MedicineController : ApiController
    {
        private readonly IMedicineService _medicineService;
        //public MedicineController(IMedicineService medicineService)
        //{
        //    _medicineService = medicineService;
        //}

        // GET: api/Medicine
        public IEnumerable<string> Get()
        {
            // var response =  _medicineService.GetMedicines();
            return new string[] { "value1", "value2" };
        }

        // GET: api/Medicine/5
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Medicine
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/Medicine/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Medicine/5
        public void Delete(int id)
        {
        }
    }
}
