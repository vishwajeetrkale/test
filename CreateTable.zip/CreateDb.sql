USE [master]
GO

/****** Object:  Database [MedicineTrakcingSystemDb]    Script Date: 10/21/2019 12:31:13 PM ******/
CREATE DATABASE [MedicineTrakcingSystemDb]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'MedicineTrakcingSystemDb', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.SQLEXPRESS\MSSQL\DATA\MedicineTrakcingSystemDb.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'MedicineTrakcingSystemDb_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.SQLEXPRESS\MSSQL\DATA\MedicineTrakcingSystemDb_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
GO

IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [MedicineTrakcingSystemDb].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET ANSI_NULL_DEFAULT OFF 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET ANSI_NULLS OFF 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET ANSI_PADDING OFF 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET ANSI_WARNINGS OFF 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET ARITHABORT OFF 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET AUTO_CLOSE OFF 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET AUTO_SHRINK OFF 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET AUTO_UPDATE_STATISTICS ON 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET CURSOR_DEFAULT  GLOBAL 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET CONCAT_NULL_YIELDS_NULL OFF 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET NUMERIC_ROUNDABORT OFF 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET QUOTED_IDENTIFIER OFF 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET RECURSIVE_TRIGGERS OFF 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET  DISABLE_BROKER 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET TRUSTWORTHY OFF 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET PARAMETERIZATION SIMPLE 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET READ_COMMITTED_SNAPSHOT OFF 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET HONOR_BROKER_PRIORITY OFF 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET RECOVERY SIMPLE 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET  MULTI_USER 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET PAGE_VERIFY CHECKSUM  
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET DB_CHAINING OFF 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET DELAYED_DURABILITY = DISABLED 
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET QUERY_STORE = OFF
GO

ALTER DATABASE [MedicineTrakcingSystemDb] SET  READ_WRITE 
GO


