USE [MedicineTrakcingSystemDb]
GO
/****** Object:  Table [dbo].[MedicineQuantity]    Script Date: 10/21/2019 12:30:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MedicineQuantity](
	[Id] [nvarchar](250) NOT NULL,
	[MedicineId] [nvarchar](250) NOT NULL,
	[Quantity] [bigint] NOT NULL,
 CONSTRAINT [PK_MedicineQuantity] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Medicines]    Script Date: 10/21/2019 12:30:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Medicines](
	[Id] [nvarchar](250) NOT NULL,
	[Name] [nvarchar](250) NOT NULL,
	[Brand] [nvarchar](250) NOT NULL,
	[Price] [decimal](18, 2) NOT NULL,
	[ExpiryDate] [date] NOT NULL,
	[Notes] [nvarchar](500) NULL,
 CONSTRAINT [PK_Medicines] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MedicineQuantity]  WITH CHECK ADD  CONSTRAINT [FK_MedicineQuantity_Medicines] FOREIGN KEY([MedicineId])
REFERENCES [dbo].[Medicines] ([Id])
GO
ALTER TABLE [dbo].[MedicineQuantity] CHECK CONSTRAINT [FK_MedicineQuantity_Medicines]
GO
